/**
 * Role definitions and name generation — zero dependencies.
 */
import type { RoleDefinition, AgentEntry, PresetName } from './types.js';
export declare const ROLE_DEFINITIONS: RoleDefinition[];
/** Role IDs included in each preset */
export declare const PRESET_ROLES: Record<PresetName, string[] | null>;
/** Minimum required role IDs for any team */
export declare const REQUIRED_ROLES: string[];
/**
 * Generate AgentEntry objects for the given role IDs with random unique names.
 */
export declare function generateAgents(roleIds: string[]): AgentEntry[];
/**
 * Get all role IDs (for "full" preset).
 */
export declare function getAllRoleIds(): string[];
/**
 * Check if a set of role IDs meets the minimum requirements.
 * Returns an error message string or null if valid.
 */
export declare function validateRoles(roleIds: string[]): string | null;
