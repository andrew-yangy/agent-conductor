/**
 * Minimal ANSI color helpers — zero dependencies.
 * Respects NO_COLOR env var per https://no-color.org/
 */
export declare const c: {
    bold: (s: string) => string;
    dim: (s: string) => string;
    red: (s: string) => string;
    green: (s: string) => string;
    yellow: (s: string) => string;
    blue: (s: string) => string;
    magenta: (s: string) => string;
    cyan: (s: string) => string;
    white: (s: string) => string;
};
