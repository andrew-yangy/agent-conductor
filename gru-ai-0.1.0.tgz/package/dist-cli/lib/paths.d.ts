/**
 * Path resolution — find the gru-ai package root from compiled or source context.
 */
/**
 * Walk up from the current file to find the nearest package.json with name "gru-ai".
 * Works from both:
 *  - dist-cli/lib/ (compiled npm install)
 *  - cli/lib/ (tsx dev)
 */
export declare function findPackageRoot(): string;
export declare const TEMPLATES_DIR: string;
export declare const SKILLS_SRC_DIR: string;
export declare const ROLE_TEMPLATES_DIR: string;
