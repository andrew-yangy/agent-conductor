/**
 * Scaffolding engine — creates all project files from templates.
 *
 * Takes an InitConfig and produces:
 *  - .gruai/ canonical home directory
 *  - Platform symlink (.claude/, .aider/, etc.)
 *  - .context/ tree (vision, lessons, preferences, backlog, directives, reports)
 *  - Agent personality files for selected roles
 *  - agent-registry.json for selected preset
 *  - CLAUDE.md
 *  - gruai.config.json
 *  - Welcome directive
 */
import type { InitConfig } from '../lib/types.js';
export declare function runScaffold(config: InitConfig): Promise<void>;
