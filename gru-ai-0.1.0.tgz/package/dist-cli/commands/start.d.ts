/**
 * gruai start — Launch the dashboard server.
 *
 * Checks that the project is initialized, resolves the server entry point
 * from the package, and spawns it as a child process.
 */
export declare function runStart(flags: Record<string, string | boolean>): Promise<void>;
