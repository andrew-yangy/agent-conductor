# Brainstorm
Medium directive brainstorm.
