/**
 * Centralized path resolution for the gru-ai server.
 *
 * Two root directories matter at runtime:
 *
 * 1. **Consumer project root** (`consumerRoot`): The directory where the user
 *    ran `gruai start`. This is where `.context/`, `.claude/agent-registry.json`,
 *    and session data live. Resolved from `GRUAI_PROJECT_PATH` env var (set by
 *    the CLI) or falls back to `process.cwd()`.
 *
 * 2. **Package root** (`packageRoot`): The gru-ai npm package installation
 *    directory. This is where `dist/` (built dashboard assets) and bundled
 *    defaults live. Resolved by walking up from this file's location to find
 *    the package.json with `"name": "gru-ai"`.
 */
/** The gru-ai package installation directory (contains dist/, dist-server/, etc.) */
export declare const packageRoot: string;
/** The consumer's project directory (contains .context/, .claude/, etc.) */
export declare const consumerRoot: string;
/** Path to the built dashboard assets (dist/) inside the package */
export declare function distDir(): string;
/** Path to the consumer's .context/ directory */
export declare function contextDir(): string;
/** Path to the consumer's .context/directives/ directory */
export declare function directivesDir(): string;
/**
 * Load agent-registry.json. Looks in:
 * 1. Consumer's .claude/agent-registry.json
 * 2. Consumer's .gruai/agent-registry.json (scaffold output)
 * 3. Bundled default in package's .claude/agent-registry.json
 *
 * Returns the parsed JSON or null if none found.
 */
export declare function loadAgentRegistry(): unknown;
